function [U] = controller(X, planned_trajectory)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% function [U] = controller(X)
%
% controller for the single-track model
%
% inputs: x (x position), y (y position), v (velocity), beta
% (side slip angle), psi (yaw angle), omega (yaw rate), x_dot (longitudinal
% velocity), y_dot (lateral velocity), psi_dot (yaw rate (redundant)), 
% varphi_dot (wheel rotary frequency)
%
% external inputs (from 'racetrack.mat'): t_r_x (x coordinate of right 
% racetrack boundary), t_r_y (y coordinate of right racetrack boundary),
% t_l_x (x coordinate of left racetrack boundary), t_l_y (y coordinate of
% left racetrack boundary)
%
% outputs: delta (steering angle ), G (gear 1 ... 5), F_b (braking
% force), zeta (braking force distribution), phi (gas pedal position)
%
% files requested: racetrack.mat
%
% This file is for use within the "Project Competition" of the "Concepts of
% Automatic Control" course at the University of Stuttgart, held by F.
% Allgoewer.
%
% prepared by J. M. Montenbruck, Dec. 2013 
% mailto:jan-maximilian.montenbruck@ist.uni-stuttgart.de
%
% written by *Z. He*, *Sep. 2024*



%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
zeta = 1;%braking force only on rear wheel
k_g = 9.5;%relavant to Gear selection 
a_braking = 12.4;%real a_braking is less than Fbmax/m(12.1). Bigger a_braking means shorter braking distance before cornering.
k_steering = 3;%P_controller for steer angle
v1 = 6.5;%theoretical maximum is 9. Calculating four Maximum Velocity from Centripetal Force, also considering a coefficience to avoid away from the boudaries, so change it experimentally
v2 = 13.1;%theoretical maximum is 15.6
v3 = 5.5;%theoretical maximum is 7
v4 = 8.2;%theoretical maximum is 9
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% state vector
x=X(1); % x position
y=X(2); % y position
v=X(3); % velocity (strictly positive)
beta=X(4); % side slip angle
psi=X(5); % yaw angle
omega=X(6); % yaw rate
x_dot=X(7); % longitudinal velocity
y_dot=X(8); % lateral velocity
psi_dot=X(9); % yaw rate 
varphi_dot=X(10); % wheel rotary frequency (strictly positive)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% racetrack
% load('racetrack.mat','t_r'); % load right  boundary from *.mat file
% load('racetrack.mat','t_l'); % load left boundary from *.mat file
% t_r_x=t_r(:,1); % x coordinate of right racetrack boundary
% t_r_y=t_r(:,2); % y coordinate of right racetrack boundary
% t_l_x=t_l(:,1); % x coordinate of left racetrack boundary
% t_l_y=t_l(:,2); % y coordinate of left racetrack boundary
% %% planning trajectory
% pt_x = (t_r_x+t_l_x)/2; % x coordinate of planning trajectory 1950x1 double
% pt_y = (t_r_y+t_l_y)/2; % y coordinate of planning trajectory 1950x1 double
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STATE FEEDBACK %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pt_x = planned_trajectory(:, 1);  % 
pt_y = planned_trajectory(:, 2);  % 
dist = (pt_x-x).^2+(pt_y-y).^2 ;% distance between pos_car and pos_ref
n_pos_t = find(dist == min(dist),1);%position of point from planning trajectory, which is the nearest point between the car position and the planning trajectory

% Start: first straight line part
if pt_x(n_pos_t) == -2.5 && 0 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 250 
    % steering angle control
    future_t = n_pos_t+5; %pointer of reference position lie on next 5 index of position of car
    psi_v = [cos(psi),sin(psi),0];%yaw angle vector
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];%future trajectory vector compared to real-time position
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));%angel between pos_ref and pos_car+5(future trajectory)
    delta=d_psi(3)*k_steering; % steering angle (using asin function to have negative and positive angle)
    % gear selection
    G=1+ceil(v/k_g); %start from int 1, selecting according to real-time velocity
    if G>5
       G = 5;%upper bounded of gear selection
    end
    % braking force and pedal position controll while accelerating
    Fb=0; % no braking force when on straight line
    phi=0.6; % gas pedal position (in handout (4.9) to find a approximate maximum value)
    
    % braking point controll
    braking_dist = (v^2-v1^2)/2/a_braking; %calculate the braking distance to ensure defined velocity to be reached before cornering

    if y>250-braking_dist && y<=260 && v>v1 
        Fb = 15000;%fully braking
        phi = 0;% no acceleration
    end

% first two corner
elseif pt_x(n_pos_t) <= -2.5 && pt_x(n_pos_t)>-32.5 && 240 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 260 
    
    future_t = n_pos_t+8; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering; 
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    % two point controller, which help the v unchanged while cornering
    if  x<=-2.5 
        if v<v1
            Fb = 0;
            phi = 0.2;%small accerleration
        else
            Fb = 1500;%small braking force
            phi = 0;
        end
    end
    
elseif pt_x(n_pos_t) == -32.5 && 250 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 400 % 2nd straight section
    
    future_t = n_pos_t+5; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering;
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    Fb=0; 
    phi=0.6; 

    braking_dist = (v^2-v2^2)/2/a_braking; 
    
    if y>400-braking_dist && y<=410 && v>v2 
        Fb = 15000;
        phi =0;
    end

% second corner (R=25m)
elseif 400 <= pt_y(n_pos_t)  
    
    future_t = n_pos_t+10; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering;
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    if  true 
        if v<v2
            Fb = 0;
            phi = 0.2;
        else
            Fb = 1500;
            phi = 0;
        end
    end
% third straight line part
elseif pt_x(n_pos_t) == 22.5 && 300 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 400 
    
    future_t = n_pos_t+5; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering; 
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    Fb=0; 
    phi=0.6; 

    braking_dist = (v^2-v3^2)/2/a_braking; 
    if y<=305+braking_dist && y>=295 && v>v3 
        Fb = 15000;
        phi = 0;
    end
% Third corner(R=5)
elseif pt_x(n_pos_t) <= 32.5 && pt_x(n_pos_t)>22.5 && 290 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 305 
    
    future_t = n_pos_t+30; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering; 
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    if  true
        if v<v3
            Fb = 0;
            phi = 0.2;
        else
            Fb = 1500;
            phi = 0;
        end
    end
% Fourth straight line part
elseif pt_x(n_pos_t) == 32.5 && 45 <= pt_y(n_pos_t) && pt_y(n_pos_t) <= 290 
    
    future_t = n_pos_t+5; 
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering; 
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end

    Fb=0; 
    phi=0.6; 

    braking_dist = (v^2-v4^2)/2/a_braking; 
    if y<=45+braking_dist && y>=35 && v>v4 
        Fb = 15000;
        phi = 0;
    end    
% Fourth corner 
else

    future_t = n_pos_t+12; %if another circle start, avoid pointer overflow
    if future_t >1950
        future_t = future_t - 1950;
    end
    psi_v = [cos(psi),sin(psi),0];
    future_t_v = [pt_x(future_t)-x,pt_y(future_t)-y,0];
    d_psi = asin(cross(psi_v,future_t_v)/norm(psi_v)/norm(future_t_v));
    delta=d_psi(3)*k_steering; 
  
    G=1+ceil(v/k_g); 
    if G>5
        G = 5;
    end
    
    if v<v4
        Fb = 0;
        phi = 0.2;
    else
        Fb = 1500;
        phi = 0;
    end

    if n_pos_t > 1895% accelerating before out of final corner
        Fb = 0;
        phi = 0.6;
    end

end



%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% OUTPUT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
U=[delta G Fb zeta phi]; % input vector
end

