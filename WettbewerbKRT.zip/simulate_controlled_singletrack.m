function simulate_controlled_singletrack(~)
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
racetrack % builds the racetrack and saves it as racetrack.mat
%% Load racetrack boundaries
clc;
clear;
load('racetrack.mat', 't_r', 't_l');  % Load right and left boundaries from .mat file

% Extract x and y coordinates for the racetrack boundaries
t_r_x = t_r(:,1);  % x coordinate of right racetrack boundary
t_r_y = t_r(:,2);  % y coordinate of right racetrack boundary
t_l_x = t_l(:,1);  % x coordinate of left racetrack boundary
t_l_y = t_l(:,2);  % y coordinate of left racetrack boundary

%% Trajectory planning (only once)
pt_x = (t_r_x + t_l_x) / 2;  % x coordinate of planning trajectory
pt_y = (t_r_y + t_l_y) / 2;  % y coordinate of planning trajectory

% Combine trajectory points into a matrix for easier handling
planned_trajectory = [pt_x, pt_y];  % 1950x2 double

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INTEGRATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
X_0=[-2.5;0;0;0;pi/2;0;0;0;0;0]; % initial value for integration
Y = ode1(@singletrack, 0:0.001:61.49, X_0, planned_trajectory); % integrate with step zise 0.001
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EVALUATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot_racetrack % plots the racetrack and your result
end